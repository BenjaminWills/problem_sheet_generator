Certainly, here's a problem sheet with 5 questions about addition:

1. Find the sum of 14 and 29.
2. The width of a rectangle is 8 meters and its length is 12 meters. What is the total area of the rectangle?
3. A candy store has 642 candies in one jar and 425 candies in another jar. How many candies are there in total?
4. A pizza place sold 187 pizzas on Monday and 245 pizzas on Tuesday. How many pizzas did they sell in total?
5. A group of friends collected 53 seashells at the beach on Saturday, and 78 seashells on Sunday. How many seashells did they collect in total?

Feel free to mix and match the numbers or modify the wording of the questions as necessary!