Sure, here is a problem sheet with 10 questions about algebra. Make sure to show all your work for full credit.

1. Simplify the expression: $3x^2 - 2x^2 + 4x - 7$.

2. Solve the equation for $x$: $5x + 8 = 23$.

3. Find the slope of the line that passes through the points $(-3, 4)$ and $(2, 1)$.

4. Factor the expression: $3x^2 + 9x + 6$.

5. Simplify the expression: $\frac{5x^3 - 15x^2 + 10x}{5x}$.

6. Solve the equation for $x$: $2x^2 - 7x + 3 = 0$.

7. Find the equation of the line that is perpendicular to $y=2x+5$ and passes through the point $(-3, 2)$.

8. Simplify the expression: $(2x^3 - x^2 + 3x - 7) - (x^3 + 2x^2 - 5x + 3)$.

9. Solve the equation for $x$: $|2x+4| = 10$.

10. Factor the expression: $4x^2 - 25$.