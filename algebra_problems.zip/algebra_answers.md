Sure, here are the answers to the algebra problem sheet:

1. $x^2 + 4x - 7$
2. $x = 3$
3. $-\frac{1}{5}$
4. $3(x+1)(x+2)$
5. $x^2 - 3x + 2$
6. $x=\frac{1}{2}, x=3$
7. $y = -\frac{1}{2}x - \frac{1}{2}$
8. $x^3 + x^2 - 2x - 10$
9. $x=3, x=-7$
10. $(2x+5)(2x-5)$